/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #17: PS1_Ex17_MaxInt.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */

import java.util.*;

class MaxInteger {
  
  public static void main(String[] args) {
    
    Scanner sc = new Scanner(System.in);
    
    System.out.print("Enter three integers: ");
    
    
    System.out.println("Maximum input integer is " );
  }
  
  // <Write a short description of the method here>
  public static int getMax(int num1, int num2, int num3) {
    
    return 0;  // stub, to be replaced by your code
  }
}