/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #07: PS1_Ex07_Investment.java
 * 
 * This program computes the amount earned given principal amount,
 * interest rate, and number of years, based on compound interest.
 * 
 * <Type your name here>
 */

import java.util.*;
import java.text.*;

class Investment {
  
  public static void main(String[] args) {
    
    
    System.out.print("Enter principal amount: ");
    
    
    System.out.print("Enter interest rate   : ");
    
    
    System.out.print("Enter number of years : ");
    
    
    
    System.out.println("Amount = $");
  }
}