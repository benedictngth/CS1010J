/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #16: PS1_Ex16_TriangleIncenter.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */

import java.util.*;
import java.text.*;

class TriangleIncenter {
  
  public static void main(String[] args) {
    

    System.out.print("Coordinates of 1st vertex: ");
    
    
    System.out.print("Coordinates of 2nd vertex: ");
    
    
    System.out.print("Coordinates of 3rd vertex: ");
    
    
    
    
    
    
    
    System.out.println("Coordinates of incenter = (" + ", " + ")");
  }
  
  // <Write a short description of the method here>
  public static double computeLength(double x1, double y1, double x2, double y2) {
    
    return 0;  // stub, to be replaced by your code
  }
}