/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #19: PS1_Ex19_LeapYear.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */

import java.util.*;

class LeapYear {
  
  public static void main(String[] args) {
    
    Scanner sc = new Scanner(System.in);
    
    System.out.print("Enter year: ");
    
    
    
    System.out.println(" is a leap year.");
    
    System.out.println(" is not a leap year.");
  }
  
  // <Write a short description of the method here>
  public static boolean isLeapYear(int year) {
    
    return false;  // stub, to be replaced by your code
  }
}