/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #12: PS1_Ex12_MagicDigit.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */

import java.util.*;

class MagicDigit {
  
  public static void main(String[] args) {
    
    
    System.out.print("Enter 1st number: ");
    
    System.out.println("Magic digit = ");
    
    System.out.print("Enter 2nd number: ");
    
    System.out.println("Magic digit = ");
  }
  
  // Take a number and return the magic digit
  public static int getMagic(int num) {
    
    return 0;  // stub, to be replaced by your code
  }
}