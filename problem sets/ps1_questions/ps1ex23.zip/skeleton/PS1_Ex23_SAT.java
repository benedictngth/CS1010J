/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #23: PS1_Ex23_SAT.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */




class SAT {
  
  public static void main(String[] args) {
    
    
    
    System.out.print("Enter scores: ");
    
    
    
    System.out.println("The SAT score is in the " +  " percentile.");
    
    
    
    System.out.println("The IQ score is " );
    
    
    System.out.println("Wow, this is amazing!");
  }
  
  // <Write a short description of the method here>
  public static int computePercentile(int verbal, int maths, int writing) {
    
    return 0;  // stub, to be replaced by your code
  }
  
  // <Write a short description of the method here>
  public static double computeIQScore(int verbal, int maths) {
    
    return 0;  // stub, to be replaced by your code
  }
}