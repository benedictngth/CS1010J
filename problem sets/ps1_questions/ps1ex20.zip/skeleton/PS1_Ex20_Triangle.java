/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #20: PS1_Ex20_Triangle.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */

import java.util.*;

class Triangle {
  
  public static void main(String[] args) {
    
    Scanner sc = new Scanner(System.in);
    
    
    
    
    System.out.println("Equilateral");
    
    System.out.println("Not a triangle");
    
    System.out.println("Isosceles");
    
    System.out.println("Scalene");
  }
}