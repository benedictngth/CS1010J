/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #09: PS1_Ex09_SpeedOfSound.java
 * 
 * This program calculates the speed of sound in air of a given temperature.
 * 
 * <Type your name here>
 */


class SpeedOfSound {
  
  public static void main(String[] args) {
    
    
    System.out.print("Temperature in degree Fahrenheit: ");
    

    
    System.out.println("Speed = " +  " ft/sec");
  }
  
  // Compute the speed of sound given temperature
  public static double speedOfSound(double temperature) {
    
    return 0;  // stub, to be replaced by your code
  }
}