/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #11: PS1_Ex11_Root.java
 * 
 * <Fill in a short description of this program>
 * 
 * <Type your name here>
 */




class Root {
  
  public static void main(String[] args) {
    
    
    System.out.print("Enter coefficients (a b c): ");
    
    
    
    System.out.println("Bigger root is " );
    
  }
  
  // Take the three coefficients and return the bigger root
  public static double getRoot(double a, double b, double c) {
    
    return 0;  // stub, to be replaced by your code
  }
}