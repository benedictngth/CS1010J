/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #06: PS1_Ex06_TriangleCentroid.java
 * 
 * This program computes the centroid (G) of a triangle
 * given the coordinates of three vertices.
 * 
 * <Type your name here>
 */

import java.util.Scanner;
import java.text.DecimalFormat;

class TriangleCentroid {
  
  public static void main(String[] args) {
    
    
    System.out.print("Coordinates of 1st vertex: ");
    
    
    System.out.print("Coordinates of 2nd vertex: ");
    
    
    System.out.print("Coordinates of 3rd vertex: ");
    
    
    System.out.println("Coordinates of centroid = (" + ", " + ")");
  }
}