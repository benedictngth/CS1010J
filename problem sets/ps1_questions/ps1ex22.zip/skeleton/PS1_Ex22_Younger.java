/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #22: PS1_Ex22_Younger.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */



class Younger {
  
  public static void main(String[] args) {
    
    
    
    System.out.print("Enter birthday for Tamil (day month year): ");
    
    
    System.out.print("Enter birthday for Alice (day month year): ");
    
    
    
    System.out.println("Alice is younger");
    
    System.out.println("Tamil and Alice are of the same age");
    
    System.out.println("Tamil is younger");
  }
}