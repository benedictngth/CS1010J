/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #25: PS1_Ex25_Packing.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */



class Packing {
  
  public static void main(String[] args) {
    
    
    
    System.out.print("Enter size of tray: ");
    
    
    System.out.print("Enter size of slab: ");
    
    
    
    System.out.println("Minimum unused area = ");
  }
}