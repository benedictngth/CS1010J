/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #21: PS1_Ex21_BMI.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */



class BMI {
  
  public static void main(String[] args) {
    
    
    System.out.print("Enter your gender (0 for female, 1 for male): ");
    
    
    System.out.print("Enter your weight (kg) and height (m): ");        
    
    
    
    
    
    System.out.println("Stuff yourself with more food!");
    
    System.out.println("Great! Maintain it!");
    
    System.out.println("Time to join the gym!");
  }
  
  // <Write a short description of the method here>
  public static int bodyType(int gender, double weight, double height) {
    
    return 0;  // stub, to be replaced by your code
  }
}