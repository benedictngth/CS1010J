/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #10: PS1_Ex10_TheeInts.java
 * 
 * This program reads three positive integers,
 * prints out their digits in hundredth position.
 * 
 * <Type your name here>
 */


class TheeInts {
  
  public static void main(String[] args) {
    
    
    System.out.print("Enter 3 positive integers: ");

  }
  
  // Take a number and return the digit in hundredth position
  public static int getHundredth(int num) {
    
    return 0;  // stub, to be replaced by your code
  }
}