/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #03: PS1_Ex03_Freezer.java
 * 
 * This program estimates the temperature in a freezer 
 * given the elapsed time (hours) since a power failure.
 * 
 * <Type your name here>
 */

import java.util.Scanner;

class Freezer {
  
  public static void main(String[] args) {
    
    Scanner sc = new Scanner(System.in);
    
    System.out.print("Enter hours and minutes since power failure: ");
    
    // read hours and minutes one by one
    
    
    
    System.out.println("Temperature in freezer = ");
  }
}