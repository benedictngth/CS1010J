/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #18: PS1_Ex18_Magnitude.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */

import java.util.*;

class Magnitude {
  
  public static void main(String[] args) {
    
    Scanner sc = new Scanner(System.in);
    
    System.out.print("Magnitude: ");
    
    
    
    
    System.out.println("Classification: Minor");
    
    System.out.println("Classification: Moderate");
    
    System.out.println("Classification: Strong");
    
    System.out.println("Classification: Major");
  }
}