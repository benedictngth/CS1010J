/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #14: PS1_Ex14_AM_GM.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */

import java.util.*;
import java.text.*;

class Means {
  
  public static void main(String[] args) {
    
    
    System.out.print("Enter 3 positive integers: ");
    
    
    
    
    
    System.out.println("Arithmetic mean = " );
    System.out.println("Geometric mean = " );
  }
  
  // <Write a short description of the method here>
  public static double computeAM(int a, int b, int c) {
    
    return 0;  // stub, to be replaced by your code
  }
  
  // <Write a short description of the method here>
  public static double computeGM(int a, int b, int c) {
    
    return 0;  // stub, to be replaced by your code
  }
}