/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #15: PS1_Ex15_Cuboid.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */

import java.util.*;
import java.text.*;

class Cuboid {
  
  public static void main(String[] args) {

    
    System.out.print("Enter length: ");
    
    System.out.print("Enter width : ");
    
    System.out.print("Enter height: ");
    
    
    
    
    System.out.println("Surface area = " );
    
    System.out.println("Diagonal = " );
  }
  
  // <Write a short description of the method here>
  public static int computeSurfaceArea(int length, int width, int height) {
    
    return 0;  // stub, to be replaced by your code
  }
  
  // <Write a short description of the method here>
  public static double computeDiagonal(int length, int width, int height) {
    
    return 0;  // stub, to be replaced by your code
  }
}