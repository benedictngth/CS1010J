/*
 * CS1010J Programming Methodology
 * Problem Set 1 Exercise #13: PS1_Ex13_Travel.java
 * 
 * <Fill in a short description of this program>
 * 
 * 
 * <Type your name here>
 */


class Travel {
  
  public static void main(String[] args) {
    
    
    System.out.print("Enter X Y coordinates for Home: ");
    
    
    System.out.print("Enter X Y coordinates for Office: ");
    
    
    System.out.print("Enter X Y coordinates for NTUC: ");
    
    
    
    
    
    System.out.println("Distance of travel is " );
  }
  
  // <Write a short description of the method here>
  public static double distance(double x1, double y1, double x2, double y2) {
    
    return 0;  // stub, to be replaced by your code
  }
}